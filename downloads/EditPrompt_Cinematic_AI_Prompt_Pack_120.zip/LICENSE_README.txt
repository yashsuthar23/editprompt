EDITPROMPT.IN - LICENSE / README

This package is prepared as a digital product starter for the website owner.

Recommended customer license wording:
- Buyer may use the prompts in personal and commercial video projects.
- Buyer may customize prompts for client work.
- Buyer may not resell, redistribute, upload, share, or repackage the prompt pack itself.
- AI platform results vary; no specific output is guaranteed.

Before selling publicly, add your business/contact details, refund policy, and final legal wording appropriate to your business.
